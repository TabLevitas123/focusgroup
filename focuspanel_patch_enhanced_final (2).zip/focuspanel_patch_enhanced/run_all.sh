#!/bin/bash
echo "Running FocusPanel GUI..."
python3 -m gui.main_window