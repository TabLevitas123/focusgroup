#!/bin/bash
echo "Launching FocusPanel..."
python3 -m gui.main_window